import os


def download_minecraft_launcher_lib():
    os.system('pip install -U git+https://gitlab.com/JakobDev/minecraft-launcher-lib.git')